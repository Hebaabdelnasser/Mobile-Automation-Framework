package jetflix_app.tests.movie_description;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
//import io.qameta.allure.Step;
import jetflix_app.base_test.BaseTest;
import org.testng.Assert;

public class MovieDescriptionStepdefs extends BaseTest {

@When("user click on movie with name {string} in home screen")
public void userClickOnMovieWithNameInHomeScreen(String movieName) {
    device.app.movieNameScreen = device.app.home.clickOnMovieName(movieName);
}

    @Then("verify that {string} in home screen should be the same in movie screen")
    public void verifyThatMovieNameInHomeScreenShouldBeTheSameInMovieScreen(String movieName) throws InterruptedException {
        Thread.sleep(3000);
        Assert.assertEquals(device.app.movieNameScreen.retrieveMovieName(),movieName);
    }
    @And("retrieve movie name in movie screen")
    public void retrieveMovieNameInMovieScreen() throws InterruptedException {
        Thread.sleep(3000);
        device.app.movieNameScreen.retrieveMovieName();
    }
}
