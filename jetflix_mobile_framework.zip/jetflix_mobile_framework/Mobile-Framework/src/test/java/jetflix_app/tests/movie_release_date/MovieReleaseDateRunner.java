package jetflix_app.tests.movie_release_date;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "src/test/java/jetflix_app/tests/movie_release_date",
        glue = {"jetflix_app/tests"},
        monochrome = true
)

public class MovieReleaseDateRunner extends AbstractTestNGCucumberTests {
}
