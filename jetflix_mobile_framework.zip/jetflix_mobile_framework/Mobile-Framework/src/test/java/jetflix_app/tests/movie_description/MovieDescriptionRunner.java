package jetflix_app.tests.movie_description;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(
        features = "src/test/java/jetflix_app/tests/movie_description",
        glue = {"jetflix_app/tests"},
        monochrome = true
)
public class MovieDescriptionRunner extends AbstractTestNGCucumberTests {
}
