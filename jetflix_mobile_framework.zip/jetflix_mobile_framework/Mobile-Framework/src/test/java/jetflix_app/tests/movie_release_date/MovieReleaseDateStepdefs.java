package jetflix_app.tests.movie_release_date;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import jetflix_app.base_test.BaseTest;
import org.testng.Assert;

public class MovieReleaseDateStepdefs extends BaseTest {
    Boolean currentState;

    @When("click on filter in home screen")
    public void clickOnFilterInHomeScreen() {
        device.app.home.clickOnFilterButton();
    }


    @And("select sort by release date in home screen")
    public void selectSortByReleaseDateInHomeScreen() {
        device.app.home.clickOnReleaseDateButton();
    }


    @And("click on close filter in home screen")
    public void clickOnCloseFilterInHomeScreen() {
        device.app.home.clickOnCloseFilterButton();
    }


    @And("get movie date in home screen")
    public void getMovieDateInHomeScreen() {
       currentState = device.app.home.getMovieDateInHomeScreen();
    }

    @Then("assert that release date filter in home screen should be the date in the future")
    public void assertThatReleaseDateFilterInHomeScreenShouldBeTheDateInTheFuture() {
        Assert.assertTrue(currentState);
    }
}
