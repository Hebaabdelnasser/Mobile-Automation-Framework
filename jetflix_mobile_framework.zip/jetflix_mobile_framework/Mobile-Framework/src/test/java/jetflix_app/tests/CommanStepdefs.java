package jetflix_app.tests;

import io.cucumber.java.en.Given;
import jetflix_app.base_test.BaseTest;


public class CommanStepdefs extends BaseTest {

    @Given("app opened and user go to home screen")
    public void appOpenedAndUserGoToHomeScreen() throws InterruptedException {
        device.launchApp();
        device.app.home.waitUntilHomeLoad();
    }
}
