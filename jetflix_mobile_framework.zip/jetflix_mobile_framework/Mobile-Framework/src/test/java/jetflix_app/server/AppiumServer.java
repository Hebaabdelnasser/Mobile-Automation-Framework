package jetflix_app.server;

import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

import java.net.URL;

public class AppiumServer {

    AppiumDriverLocalService service;

    public AppiumServer(){

        AppiumServiceBuilder builder = new AppiumServiceBuilder();
        builder.withIPAddress("127.0.0.1");
        builder.usingAnyFreePort();
        builder.withLogOutput(System.out);

        service = AppiumDriverLocalService.buildService(builder);
        service.start();
        if (service == null || !service.isRunning()) {
            throw new RuntimeException("An appium server node is not started!");
        }
    }

    public URL getCurrentServiceUrl(){
        return service.getUrl();
    }

    public void closeAppiumServer() {
        if (service.isRunning()) {
            service.stop();
        }
    }
}
