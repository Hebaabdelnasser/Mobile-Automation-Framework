package jetflix_app.screens;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import jetflix_app.base_screen.BaseScreen;
import jetflix_app.driver.DriverSingleton;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;


public class Home extends BaseScreen {

    public Home(AndroidDriver driver){
        super(driver);
    }
    private final By textView1= AppiumBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.widget.TextView[1]");
    private final By filterButton = AppiumBy.accessibilityId("Filter & Sort Movies");
    private final By releaseDateButton = AppiumBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[2]/android.widget.ScrollView[2]/android.view.View[4]/android.widget.RadioButton");
    private final By closeFilterButton = AppiumBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[2]/android.view.View/android.view.View[1]/android.widget.Button");

    private final By movieDateText = AppiumBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[1]/android.view.View[1]/android.widget.TextView[2]");
    public void waitUntilHomeLoad(){
        waitForElementToBeVisible(textView1);
    }


    public MovieNameScreen clickOnMovieName(String movieName) {
        String xpath = "//android.view.View[contains(@content-desc, concat('Poster Image of ', '" + movieName + "'))]";
        WebElement movieElement = findElementByXPath(xpath);
        movieElement.click();
        return new MovieNameScreen(driver);
    }
    public void clickOnFilterButton(){
        findElement(filterButton).click();
    }
    public void clickOnReleaseDateButton(){
        findElement(releaseDateButton).click();
    }

    public void clickOnCloseFilterButton(){findElement(closeFilterButton).click();}
    public Boolean getMovieDateInHomeScreen() {

        List<WebElement> elements = DriverSingleton.getDriverSingleton().getDriver().findElements(AppiumBy.xpath(".//android.view.View/android.view.View/android.view.View/android.view.View/android.widget.TextView[2]"));
        Boolean flag= false;
        for (WebElement element : elements) {
            {

                LocalDate futuredate = LocalDate.parse(element.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                LocalDate currentDate = LocalDate.now();
                if (futuredate.isBefore(currentDate)) {
                     flag=false;
                     break;

                } else if (futuredate.isEqual(currentDate)) {
                     flag=false;
                     break;
                } else {
                     flag=true;
                }

            }
    }    return flag;
}
}
