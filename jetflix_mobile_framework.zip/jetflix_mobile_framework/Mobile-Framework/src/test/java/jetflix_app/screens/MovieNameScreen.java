package jetflix_app.screens;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import jetflix_app.base_screen.BaseScreen;

public class MovieNameScreen extends BaseScreen {
    public MovieNameScreen(AndroidDriver driver) {
        super(driver);
    }
    public String retrieveMovieName() throws InterruptedException {
        Thread.sleep(3000);
        String movieElement = findElement(AppiumBy.xpath(".//android.widget.TextView[1]")).getText();
        Thread.sleep(3000);
        return movieElement;
    }

}


