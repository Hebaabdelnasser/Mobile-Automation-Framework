package jetflix_app.base_test;

import jetflix_app.device.Device;
import jetflix_app.server.AppiumServer;


public class BaseTest {
    public AppiumServer server = new AppiumServer();
    protected static Device device = new Device();
}
