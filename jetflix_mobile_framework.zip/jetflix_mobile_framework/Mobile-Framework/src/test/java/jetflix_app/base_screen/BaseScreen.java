package jetflix_app.base_screen;

import io.appium.java_client.android.AndroidDriver;
import jetflix_app.driver.DriverSingleton;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.NoSuchElementException;

public class BaseScreen{
    protected AndroidDriver driver;
    private static WebDriverWait wait = new WebDriverWait(DriverSingleton.getDriverSingleton().getDriver(), Duration.ofSeconds(30));
    private static  Actions action = new Actions(DriverSingleton.getDriverSingleton().getDriver());
    public BaseScreen(AndroidDriver driver){
        this.driver = driver;
    }

    public void waitForElementToBeVisible(By elementBy) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(elementBy));
    }
    public void moveToElement(By element){
        action.moveToElement(findElement(element)).perform();
    }
    public WebElement findElement(By locator) {
        try {
//            moveToElement(locator);
            waitForElementToBeVisible(locator);
            return DriverSingleton.getDriverSingleton().getDriver().findElement(locator);
        } catch (TimeoutException e) {
            e.printStackTrace();
            return null;
        }
    }
    public WebElement findElementByXPath(String xpath) {
        WebElement element = null;

        try {
            element = driver.findElement(By.xpath(xpath));
        } catch (NoSuchElementException e) {
            scrollIntoView(xpath);
            element = driver.findElement(By.xpath(xpath));
        }

        return element;
    }
    public void scrollIntoView(String xpath) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement element = findElement(By.xpath(xpath));
        js.executeScript("arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'center' });", element);
    }

}
