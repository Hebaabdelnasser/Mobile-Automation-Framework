package jetflix_app.device;


import jetflix_app.driver.DriverSingleton;
import jetflix_app.my_app.JetflixApp;
import org.openqa.selenium.By;

public class Device {
      private final DriverSingleton driverSingleton = DriverSingleton.getDriverSingleton();
      public JetflixApp app = new JetflixApp(driverSingleton.getDriver());
      private static final String appPackage = "com.yasinkacmaz.jetflix.debug";

      public void launchApp() {
            driverSingleton.getDriver().activateApp(appPackage);
      }
      public boolean elementIsDisplayed(By locator) {
            try {
                  return DriverSingleton.getDriverSingleton().getDriver().findElement(locator).isDisplayed();
            } catch (Exception e) {
                  return false;
            }
      }

}
