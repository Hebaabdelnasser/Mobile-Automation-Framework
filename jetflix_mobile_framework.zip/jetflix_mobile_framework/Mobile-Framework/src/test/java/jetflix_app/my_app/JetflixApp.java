package jetflix_app.my_app;

import io.appium.java_client.android.AndroidDriver;
import jetflix_app.screens.Home;
import jetflix_app.screens.MovieNameScreen;


public class JetflixApp {

    public Home home;
    public MovieNameScreen movieNameScreen;
    public JetflixApp(AndroidDriver driver){

        this.home = new Home(driver);
    }
}
