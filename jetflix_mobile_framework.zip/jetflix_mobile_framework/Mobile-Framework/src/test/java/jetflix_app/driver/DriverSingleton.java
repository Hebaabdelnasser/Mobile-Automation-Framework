package jetflix_app.driver;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import jetflix_app.base_test.BaseTest;


public class DriverSingleton extends BaseTest{
    private static final String platformName = "Android";
    private static final String platfromVersion = "10";
    private static final String deviceName = "emulator-5554";
    private static final String appPackage = "com.yasinkacmaz.jetflix.debug";
    private static final String appActivity = "com.yasinkacmaz.jetflix.ui.main.MainActivity";
    private static final String app = "D:\\jetflix_mobile_framework\\Mobile-Framework\\resources\\app-debug.apk";

    private static final String automationName ="uiAutomator2";
    private static DriverSingleton driverSingleton = null;
    private AndroidDriver driver;
    public DriverSingleton() {
        setUp();
    }
    public static DriverSingleton getDriverSingleton(){
        if (driverSingleton == null)
            driverSingleton = new DriverSingleton();
        return driverSingleton;
    }

    public AndroidDriver getDriver(){
        return driver;
    }
    public void setUp(){

        UiAutomator2Options options = new UiAutomator2Options();
        options.setDeviceName(deviceName);
        options.setPlatformName(platformName);
        options.setPlatformVersion(platfromVersion);
        options.setAppActivity(appActivity);
        options.setAppPackage(appPackage);
        options.setAutomationName(automationName);
        options.setApp(app);
        options.setCapability("newCommandTimeout", 1200);
        options.setCapability("autoDismissAlerts", true);
        options.setCapability("unicodeKeyboard", true);
        options.setCapability("resetKeyboard", true);

        driver= new AndroidDriver(server.getCurrentServiceUrl(),options);

    }
}
